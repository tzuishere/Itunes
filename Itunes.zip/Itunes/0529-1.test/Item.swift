import Foundation

struct SearchResponse: Codable {
    let results: [Item]
}

struct Item: Codable {
    let trackName: String
    let releaseDate: Date
    let artworkUrl100: URL
}
