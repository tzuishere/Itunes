import UIKit
import Kingfisher

class ViewController: UIViewController
{
    @IBOutlet weak var dogsTableView: UITableView!
    var items = [Item]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        fetchDogs()
    }
    
    func fetchDogs()
    {
        let urlString = "https://itunes.apple.com/search?term=celine&media=music"
        let url = URL(string: urlString)!
        
        URLSession.shared.dataTask(with: url)
        {
            data, response, error in
            if let data
            {
                let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
                do {
                    let searchResponse = try decoder.decode(SearchResponse.self, from: data)
                    
                    self.items = searchResponse.results
                    DispatchQueue.main.async
                    {
                      self.dogsTableView.reloadData() // 更新 UITableView
                    }
                } catch {
                    print(error)
                }
            }
        }.resume()
    }
}

extension ViewController: UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int
    {
        return items.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as! TableViewCell
        let item = items[indexPath.row]
        
        cell.trackNameLabel.text = item.trackName
        cell.imgView.kf.setImage(with: item.artworkUrl100)
        
        //將日期物件轉換為字串
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy/MM/dd" //根據需要的日期格式調整
        let dateString = formatter.string(from: item.releaseDate) //將Date轉換為String
        cell.releaseDateLabel.text = dateString
        
        return cell
    }
}


/*
 URLRequest：only represents information about the request.
 一個URLRequest物件，描述了要發送的網絡請求的詳細資訊，包括URL、HTTP方法、標頭字段、主體內容等。
 URLSession：to send the request to a server.
 
 
 completionHandler：一個回呼（closure）函式，當請求完成時被呼叫。它接收三個參數：Data（回應的內容資料），URLResponse（回應的元資訊，如狀態碼、標頭等）和Error（發生的錯誤）。
 */
